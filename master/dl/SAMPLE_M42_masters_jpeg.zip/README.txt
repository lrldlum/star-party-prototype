SAMPLE DATA - Star Party prototype.
These are tiny mock files to demo Download all; they are not real masters.
Contents: 7 masters (Color, L, R, G, B, Ha, OIII) + RGB composite + 4 saved products
(HaRGB, Color+RGB, HOO, Auto-HaRGB) = 12 files + this README.
- SII: not included (no SII subs yet)
- SHO composite: not included (needs SII master)
+ SAMPLE_M42_Color_master.jpg
+ SAMPLE_M42_L_master.jpg
+ SAMPLE_M42_R_master.jpg
+ SAMPLE_M42_G_master.jpg
+ SAMPLE_M42_B_master.jpg
+ SAMPLE_M42_Ha_master.jpg
+ SAMPLE_M42_OIII_master.jpg
+ SAMPLE_M42_RGB_master.jpg
+ SAMPLE_M42_HaRGB_master.jpg
+ SAMPLE_M42_Color+RGB_master.jpg
+ SAMPLE_M42_HOO_master.jpg
+ SAMPLE_M42_Auto-HaRGB_master.jpg
