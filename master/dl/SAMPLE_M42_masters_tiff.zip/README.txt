SAMPLE DATA - Star Party prototype.
These are tiny mock files to demo Download all; they are not real masters.
- SII: not included (no SII subs yet)
- SHO composite: not included (needs SII master)
+ SAMPLE_M42_Color_master.tif
+ SAMPLE_M42_L_master.tif
+ SAMPLE_M42_R_master.tif
+ SAMPLE_M42_G_master.tif
+ SAMPLE_M42_B_master.tif
+ SAMPLE_M42_Ha_master.tif
+ SAMPLE_M42_OIII_master.tif
+ SAMPLE_M42_RGB_master.tif
+ SAMPLE_M42_HaRGB_master.tif
+ SAMPLE_M42_Color+RGB_master.tif
+ SAMPLE_M42_HOO_master.tif
+ SAMPLE_M42_Auto-HaRGB_master.tif
